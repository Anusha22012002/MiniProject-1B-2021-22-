host = 'localhost'
user = 'root'
password = 'password'
database = 'student_database'